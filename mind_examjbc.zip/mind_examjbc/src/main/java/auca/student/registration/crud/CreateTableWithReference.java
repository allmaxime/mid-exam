package auca.student.registration.crud;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateTableWithReference {

    // JDBC variables for opening, closing and managing connection
    private static Connection connection;
    private static Statement statement;

    public static void main(String[] args) {
        try {
            // Step 1: Open a connection
            System.out.println("Connecting to database...");
            Connection con = ConnectDB.connect();
            // Step 2: Create a statement
            System.out.println("Creating tables...");
            statement = connection.createStatement();

            // Step 3: Execute SQL queries to create tables
            String createsemesterTable = "CREATE TABLE IF NOT EXISTS semester ("
                    + "semester_id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "semester_name VARCHAR(255),"
                    + "stating_date VARCHAR(50),"
                    + "end_date VARCHAR(50))";
                    		
            String createdepartmentTable = "CREATE TABLE IF NOT EXISTS department ("
                    + "department_id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "department_name VARCHAR(255) )";

            String createcourseTable = "CREATE TABLE IF NOT EXISTS course ("
                    + "course_id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "course_code VARCHAR(255),"
                    + "course_name VARCHAR(255),"
                    + "FOREIGN KEY (semester_id) REFERENCES semester(semester_id)'"
                    + "FOREIGN KEY (department_id) REFERENCES department(department_id))";
            
            String createcoursedefinitionTable = "CREATE TABLE IF NOT EXISTS course_definition ("
                    + "course_definition_id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "course_definition_code VARCHAR(255),"
                    + "course_definition_description VARCHAR(255),"
                    + "FOREIGN KEY (course_id) REFERENCES course(course_id))";
            
            

            String createteacherTable = "CREATE TABLE IF NOT EXISTS teacher ("
                    + "teacher_id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "frist_name VARCHAR(255),"
                    + "last_name VARCHAR(255),"
                    + "qualification VARCHAR(255),"
                    + "FOREIGN KEY (course_id) REFERENCES semester(course_id))";
            
            

            statement.executeUpdate(createsemesterTable);
            statement.executeUpdate(createsemesterTable);
            System.out.println("Tables created successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                // Step 4: Close the statement and connection
                if (statement != null) statement.close();
                if (connection != null) connection.close();
                System.out.println("Resources closed.");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
